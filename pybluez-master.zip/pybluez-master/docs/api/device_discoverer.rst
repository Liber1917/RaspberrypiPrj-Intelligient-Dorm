DeviceDiscoverer
----------------

.. todo:: Add documentation for the DeviceDiscover class and its methods.

.. currentmodule:: bluetooth

.. autoclass:: DeviceDiscoverer
  :show-inheritance:
  :members:
  :undoc-members: